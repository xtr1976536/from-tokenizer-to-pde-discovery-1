从分词器到pde发现，第二次修订。

使用XeLaTeX与BibTeX/latexmk编译：进入latex目录运行 latexmk -xelatex main.tex。
正文固定使用种子525，主实验以八个案例为列；其余种子见附录。主文保留三组重画的图，使用参考论文的浅绿/浅紫配色。
revise_assets.py重建主图与主表，种子525的新结构统计保存在data/seed525_novelty.csv。原始实验结果未修改。
